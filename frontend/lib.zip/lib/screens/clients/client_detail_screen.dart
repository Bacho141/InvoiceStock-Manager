import 'package:flutter/material.dart';
import '../../controllers/client_controller.dart';
import '../../controllers/creance_controller.dart';
import '../../models/client.dart';
import '../../models/client.dart' as model; // Ajout de l'import avec alias
import 'client_form_screen.dart';
import 'client_form_test_screen.dart'; // Ajout de l'import pour le test screen
import 'client_list_screen.dart'; // Ajout de l'import pour _ClientFormModal
import '../../layout/main_layout.dart'; // Import du MainLayout
import '../../widgets/creance_card.dart';


/// Écran de détails complets d'un client
/// Selon le plan Sprint 2 - Frontend Core
class ClientDetailScreen extends StatefulWidget {
  final String clientId;

  const ClientDetailScreen({Key? key, required this.clientId})
    : super(key: key);

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen>
    with SingleTickerProviderStateMixin {
  final ClientController _clientController = ClientController();
  final CreanceController _creanceController = CreanceController();
  late TabController _tabController;

  Client? _client;
  bool _isLoading = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadClientDetails();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadClientDetails() async {
    setState(() {
      _isLoading = true;
      _error = '';
    });

    try {
      final success = await _clientController.selectClient(widget.clientId);
      if (success) {
        setState(() {
          _client = _clientController.selectedClient;
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Client non trouvé';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Erreur chargement client: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshData() async {
    await _loadClientDetails();
  }

  void _navigateToEdit() {
    if (_client != null) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            width: MediaQuery.of(context).size.width * 0.6,
            height: MediaQuery.of(context).size.height * 0.8,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: ClientFormModal(
              client: _client,
              onSaved: () {
                Navigator.pop(context);
                _refreshData();
              },
              onCancel: () => Navigator.pop(context),
            ),
          ),
        ),
      );
    }
  }

  Future<void> _deleteClient() async {
    if (_client == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmer la suppression'),
        content: Text(
          'Êtes-vous sûr de vouloir supprimer ${_client!.fullName} ?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final result = await _clientController.deleteClient(_client!.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message']),
            backgroundColor: result['success'] ? Colors.green : Colors.red,
          ),
        );
        if (result['success']) {
          // Fermer la modale après suppression
          Navigator.pop(context);
        }
      }
    }
  }

  Future<void> _addCommunication() async {
    if (_client == null) return;

    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (context) => _CommunicationDialog(),
    );

    if (result != null) {
      final response = await _creanceController.addCommunication(
        _client!.id,
        type: result['type']!,
        subject: result['subject']!,
        content: result['content']!,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(response['message']),
            backgroundColor: response['success'] ? Colors.green : Colors.red,
          ),
        );
        if (response['success']) {
          _refreshData();
        }
      }
    }
  }

  Future<void> _updateScore() async {
    if (_client == null) return;

    final response = await _creanceController.updateClientScore(_client!.id);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(response['message']),
          backgroundColor: response['success'] ? Colors.green : Colors.red,
        ),
      );
      if (response['success']) {
        _refreshData();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MainLayout(
      currentRoute: '/clients/detail',
      pageTitle: _client?.fullName ?? 'Détails Client',
      showStoreSelector: false, // Désactivation du sélecteur de store
      child: Scaffold(
        appBar: AppBar(
          title: Text(_client?.fullName ?? 'Détails Client'),
          backgroundColor: const Color(0xFF7717E8),
          foregroundColor: Colors.white,
          actions: [
            if (_client != null) ...[
              IconButton(
                onPressed: _navigateToEdit,
                icon: const Icon(Icons.edit),
                tooltip: 'Modifier',
              ),
              IconButton(
                onPressed: _addCommunication,
                icon: const Icon(Icons.message),
                tooltip: 'Ajouter communication',
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  switch (value) {
                    case 'update_score':
                      _updateScore();
                      break;
                    case 'delete':
                      _deleteClient();
                      break;
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'update_score',
                    child: Text('Recalculer score'),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text('Supprimer client'),
                  ),
                ],
              ),
            ],
          ],
        ),
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, size: 64, color: Colors.red[300]),
            const SizedBox(height: 16),
            Text(_error, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadClientDetails,
              child: const Text('Réessayer'),
            ),
          ],
        ),
      );
    }

    if (_client == null) {
      return const Center(child: Text('Client non trouvé'));
    }

    return Column(
      children: [
        _buildClientHeader(),
        _buildTabBar(),
        Expanded(child: _buildTabBarView()),
      ],
    );
  }

  Widget _buildClientHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        border: Border(bottom: BorderSide(color: Colors.grey[300]!)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundColor: _client!.status == 'active'
                ? Colors.green
                : _client!.status == 'blocked'
                ? Colors.red
                : Colors.grey,
            child: Text(
              _client!.firstName.isNotEmpty
                  ? _client!.firstName[0].toUpperCase()
                  : '?',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _client!.fullName,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '${_client!.phone ?? 'N/A'} • ${_client!.categoryDisplay}',
                  style: const TextStyle(fontSize: 16, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildStatusChip(),
                    const SizedBox(width: 8),
                    _buildScoreChip(),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip() {
    Color color;
    String label;
    switch (_client!.status) {
      case 'active':
        color = Colors.green;
        label = 'Actif';
        break;
      case 'blocked':
        color = Colors.red;
        label = 'Bloqué';
        break;
      default:
        color = Colors.grey;
        label = 'Inactif';
    }

    return Chip(
      label: Text(label, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
    );
  }

  Widget _buildScoreChip() {
    final score = _client!.creditScore;
    Color color;
    if (score >= 8) {
      color = Colors.green;
    } else if (score >= 6) {
      color = Colors.blue;
    } else if (score >= 4) {
      color = Colors.orange;
    } else {
      color = Colors.red;
    }

    return Chip(
      label: Text(
        'Score: ${score.toStringAsFixed(1)}/10',
        style: const TextStyle(color: Colors.white),
      ),
      backgroundColor: color,
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: _tabController,
      labelColor: const Color(0xFF7717E8),
      unselectedLabelColor: Colors.grey,
      indicatorColor: const Color(0xFF7717E8),
      tabs: const [
        Tab(icon: Icon(Icons.info), text: 'Informations'),
        Tab(icon: Icon(Icons.analytics), text: 'Financier'),
        Tab(icon: Icon(Icons.history), text: 'Historique'),
        Tab(icon: Icon(Icons.account_balance), text: 'Créances'),
      ],
    );
  }

  Widget _buildTabBarView() {
    return TabBarView(
      controller: _tabController,
      children: [
        _buildInfoTab(),
        _buildFinancialTab(),
                _buildHistoryTab(),
        _buildCreancesTabV2(),
      ],
    );
  }

  Widget _buildInfoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildInfoSection('Contact', [
            _buildInfoRow('Téléphone', _client!.phone ?? 'N/A'),
            _buildInfoRow('Email', _client!.email ?? 'N/A'),
            _buildInfoRow('Adresse', _client!.address ?? 'N/A'),
            _buildInfoRow('Ville', _client!.city ?? 'N/A'),
            _buildInfoRow('Région', _client!.region ?? 'N/A'),
          ]),
          const SizedBox(height: 16),
          _buildInfoSection('Commercial', [
            _buildInfoRow('Entreprise', _client!.company ?? 'N/A'),
            _buildInfoRow('Type client', _client!.customerTypeDisplay),
            _buildInfoRow('Catégorie', _client!.categoryDisplay),
            _buildInfoRow('Priorité', _client!.priorityDisplay),
            _buildInfoRow('Magasin assigné', _client!.assignedStore ?? 'N/A'),
            _buildInfoRow('Commercial', _client!.assignedSalesperson ?? 'N/A'),
          ]),
          const SizedBox(height: 16),
          _buildInfoSection('Configuration', [
            _buildInfoRow(
              'Limite crédit',
              _client!.creditLimit > 0
                  ? '${(_client!.creditLimit / 1000).toStringAsFixed(0)}K F'
                  : 'Aucune limite',
            ),
            _buildInfoRow('Délai paiement', '${_client!.paymentTerms} jours'),
            _buildInfoRow(
              'Mode paiement préféré',
              _client!.preferredPaymentMethod ?? 'N/A',
            ),
            _buildInfoRow(
              'Alertes activées',
              _client!.alertsEnabled ? 'Oui' : 'Non',
            ),
            _buildInfoRow(
              'Alertes crédit',
              _client!.creditLimitAlerts ? 'Oui' : 'Non',
            ),
            _buildInfoRow(
              'Factures email',
              _client!.emailInvoices ? 'Oui' : 'Non',
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildFinancialTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildMetricCard(
            'Chiffre d\'affaires total',
            '${(_client!.totalRevenue / 1000).toStringAsFixed(0)}K F',
            Icons.trending_up,
            Colors.green,
          ),
          const SizedBox(height: 16),
          _buildMetricCard(
            'Créances actuelles',
            '${(_client!.currentOutstanding / 1000).toStringAsFixed(0)}K F',
            Icons.account_balance_wallet,
            _client!.currentOutstanding > 0 ? Colors.red : Colors.green,
          ),
          const SizedBox(height: 16),
          _buildMetricCard(
            'Score de crédit',
            '${_client!.creditScore.toStringAsFixed(1)}/10 (${_client!.creditScoreLevel})',
            Icons.star,
            _client!.creditScore >= 6 ? Colors.green : Colors.orange,
          ),
          const SizedBox(height: 16),
          _buildMetricCard(
            'Délai de paiement moyen',
            '${_client!.averagePaymentDelay} jours',
            Icons.schedule,
            _client!.averagePaymentDelay <= _client!.paymentTerms
                ? Colors.green
                : Colors.red,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildMetricCard(
                  'Nombre de factures',
                  '${_client!.invoiceCount}',
                  Icons.receipt,
                  Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildMetricCard(
                  'Facture moyenne',
                  _client!.invoiceCount > 0
                      ? '${((_client!.totalRevenue / _client!.invoiceCount) / 1000).toStringAsFixed(0)}K F'
                      : '0 F',
                  Icons.calculate,
                  Colors.purple,
                ),
              ),
            ],
          ),
          if (_client!.lastInvoiceDate != null) ...[
            const SizedBox(height: 16),
            _buildMetricCard(
              'Dernière facture',
              '${DateTime.now().difference(_client!.lastInvoiceDate!).inDays} jours',
              Icons.access_time,
              Colors.grey,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHistoryTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          if (_client!.communicationHistory.isNotEmpty) ...[
            Text(
              'Historique des communications (${_client!.communicationHistory.length})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _client!.communicationHistory.length,
              itemBuilder: (context, index) {
                final comm = _client!.communicationHistory[index];
                return Card(
                  child: ListTile(
                    leading: Icon(_getCommunicationIcon(comm.type)),
                    title: Text(comm.subject ?? 'Sans sujet'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(comm.content ?? 'Aucun contenu'),
                        const SizedBox(height: 4),
                        Text(
                          'Le ${comm.date.day}/${comm.date.month}/${comm.date.year}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                    trailing: Chip(
                      label: Text(comm.typeDisplay),
                      backgroundColor: _getCommunicationColor(comm.type),
                    ),
                  ),
                );
              },
            ),
          ] else ...[
            const Center(
              child: Column(
                children: [
                  Icon(Icons.history, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('Aucune communication enregistrée'),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCreancesTab() {
    // Création d'un objet OverdueInvoice fictif pour obtenir les informations de créance
    // Puisque nous sommes dans le contexte d'un client spécifique, nous créons un objet
    // avec les données du client pour pouvoir utiliser les méthodes du CreanceController
    final client = _client!;

    return FutureBuilder<List<model.OverdueInvoice>>(
      future: _creanceController.loadClientOverdueInvoices(client.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Erreur: ${snapshot.error}'));
        }

        final overdueInvoices = snapshot.data ?? [];

        // Regroupement des factures par client
        final Map<String, List<model.OverdueInvoice>> groupedInvoices = {};
        for (final invoice in overdueInvoices) {
          final clientId = invoice.client.id;
          if (!groupedInvoices.containsKey(clientId)) {
            groupedInvoices[clientId] = [];
          }
          groupedInvoices[clientId]!.add(invoice);
        }

        // Création des résumés par client
        final clientSummaries = groupedInvoices.entries.map((entry) {
          final invoices = entry.value;
          final client = invoices.first.client;
          final totalOutstanding = invoices.fold<double>(
            0,
            (sum, invoice) => sum + invoice.outstandingAmount,
          );

          return model.ClientOverdueSummary(
            client: client,
            overdueInvoices: invoices,
            totalOutstanding: totalOutstanding,
            totalInvoices: invoices.length,
          );
        }).toList();

        // Tri par montant de créance décroissant
        clientSummaries.sort(
          (a, b) => b.totalOutstanding.compareTo(a.totalOutstanding),
        );

        final totalOutstanding = clientSummaries.fold<double>(
          0,
          (sum, summary) => sum + summary.totalOutstanding,
        );

        // Création d'un objet OverdueInvoice fictif basé sur les données du client
        final fakeInvoice = model.OverdueInvoice(
          id: client.id,
          invoiceNumber: 'N/A',
          invoiceDate: DateTime.now(),
          outstandingAmount: totalOutstanding,
          daysOverdue: 0, // Calculé plus bas
          totalAmount: 0,
          paidAmount: 0,
          client: client,
        );

        final overdueDays = _creanceController.getApproximateOverdueDays(
          fakeInvoice,
        );
        final riskLevel = _creanceController.getClientRiskLevel(fakeInvoice);
        final actions = _creanceController.getRecommendedActions(fakeInvoice);

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              if (totalOutstanding > 0) ...[
                _buildMetricCard(
                  'Montant en souffrance',
                  _creanceController.formatCurrency(totalOutstanding),
                  Icons.account_balance_wallet,
                  Colors.red,
                ),
                const SizedBox(height: 16),
                _buildMetricCard(
                  'Jours de retard estimés',
                  '$overdueDays jours',
                  Icons.schedule,
                  overdueDays > 60
                      ? Colors.red
                      : overdueDays > 30
                      ? Colors.orange
                      : Colors.green,
                ),
                const SizedBox(height: 16),
                _buildMetricCard(
                  'Niveau de risque',
                  riskLevel,
                  Icons.assessment,
                  riskLevel == 'Critique'
                      ? Colors.red
                      : riskLevel == 'Élevé'
                      ? Colors.orange
                      : Colors.green,
                ),
                if (actions.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Card(
                    elevation: 4,
                    shadowColor: Colors.grey.withOpacity(0.3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Actions recommandées',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF2D3748),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: Colors.orange.withOpacity(0.3),
                                width: 1,
                              ),
                            ),
                            child: Column(
                              children: actions.map((action) {
                                return Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[300]!,
                                      ),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.warning_amber,
                                        color: Colors.orange,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Text(
                                          action,
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 24),
                // Section des créances regroupées par client
                Card(
                  elevation: 4,
                  shadowColor: Colors.grey.withOpacity(0.3),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Créances regroupées par client',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2D3748),
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (clientSummaries.isNotEmpty) ...[
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey[300]!),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              children: [
                                // En-tête du tableau
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                      colors: [
                                        Color(0xFF7717E8),
                                        Color(0xFF9C27B0),
                                      ],
                                    ),
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(12),
                                      topRight: Radius.circular(12),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.2),
                                        blurRadius: 4,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: const Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: Text(
                                          'Client',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Factures',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Retard max',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Total créances',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Lignes du tableau
                                ...clientSummaries.map((summary) {
                                  final riskColor = summary.riskColor;
                                  return Container(
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        top: BorderSide(
                                          color: Colors.grey[200]!,
                                        ),
                                      ),
                                      color: riskColor.withOpacity(0.05),
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          flex: 2,
                                          child: Text(
                                            summary.client.fullName,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Text(
                                            '${summary.totalInvoices} factures',
                                            style: const TextStyle(
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Text(
                                            '${summary.maxDaysOverdue} jours',
                                            style: const TextStyle(
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Text(
                                            _creanceController.formatCurrency(
                                              summary.totalOutstanding,
                                            ),
                                            style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              color: riskColor,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ],
                            ),
                          ),
                        ] else ...[
                          Container(
                            padding: const EdgeInsets.all(32),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: Colors.green.withOpacity(0.3),
                              ),
                            ),
                            child: const Center(
                              child: Column(
                                children: [
                                  Icon(
                                    Icons.check_circle,
                                    size: 48,
                                    color: Colors.green,
                                  ),
                                  SizedBox(height: 12),
                                  Text(
                                    'Aucune créance en retard',
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ] else ...[
                Card(
                  elevation: 4,
                  shadowColor: Colors.grey.withOpacity(0.3),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: const Icon(
                            Icons.check_circle,
                            size: 48,
                            color: Colors.green,
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Situation des créances',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2D3748),
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Aucune créance en cours',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.green,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  

  Widget _buildInfoSection(String title, List<Widget> children) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Widget _buildMetricCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getCommunicationIcon(String type) {
    switch (type) {
      case 'call':
        return Icons.phone;
      case 'email':
        return Icons.email;
      case 'meeting':
        return Icons.people;
      case 'letter':
        return Icons.mail;
      default:
        return Icons.message;
    }
  }

  Color _getCommunicationColor(String type) {
    switch (type) {
      case 'call':
        return Colors.blue;
      case 'email':
        return Colors.green;
      case 'meeting':
        return Colors.purple;
      case 'letter':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  Widget _buildCreancesTabV2() {
    final client = _client!;
    return FutureBuilder<List<model.OverdueInvoice>>(
      future: _creanceController.loadClientOverdueInvoices(client.id),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Erreur: ${snapshot.error}'));
        }

        final overdueInvoices = snapshot.data ?? [];

        if (overdueInvoices.isEmpty) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.check_circle, size: 64, color: Colors.green),
                SizedBox(height: 16),
                Text('Aucune créance pour ce client.', style: TextStyle(fontSize: 18)),
              ],
            ),
          );
        }

        final totalOutstanding = overdueInvoices.fold<double>(
          0,
          (sum, invoice) => sum + invoice.outstandingAmount,
        );

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Summary Section
              Row(
                children: [
                  Expanded(
                    child: _buildSummaryCard(
                      'Total Dû',
                      _creanceController.formatCurrency(totalOutstanding),
                      Icons.account_balance_wallet,
                      Colors.red,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildSummaryCard(
                      'Factures en Retard',
                      overdueInvoices.length.toString(),
                      Icons.receipt,
                      Colors.orange,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                'Détail des Créances',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              // List of CreanceCard
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: overdueInvoices.length,
                itemBuilder: (context, index) {
                  final invoice = overdueInvoices[index];
                  return CreanceCard(
                    invoice: invoice,
                    controller: _creanceController,
                    showActions: false,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSummaryCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              ),
              Text(
                value,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Widget modal pour créer un nouveau client avec design moderne
class ClientFormModal extends StatefulWidget {
  final VoidCallback onSaved;
  final VoidCallback onCancel;
  final Client? client;

  const ClientFormModal({
    Key? key,
    required this.onSaved,
    required this.onCancel,
    this.client,
  }) : super(key: key);

  @override
  State<ClientFormModal> createState() => _ClientFormModalState();
}

class _ClientFormModalState extends State<ClientFormModal> {
  final _formKey = GlobalKey<FormState>();
  final ClientController _clientController = ClientController();

  // Controllers
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _companyController = TextEditingController();

  // Form values
  String _customerType = 'particulier';
  String _category = 'particulier';
  String _priority = 'bas';
  bool _isLoading = false;

  bool get _isEditing => widget.client != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      _initializeForm();
    }
  }

  void _initializeForm() {
    final client = widget.client!;
    _firstNameController.text = client.firstName;
    _lastNameController.text = client.lastName;
    _phoneController.text = client.phone ?? '';
    _emailController.text = client.email ?? '';
    _addressController.text = client.address ?? '';
    _companyController.text = client.company ?? '';
    _customerType = client.customerType;
    _category = client.category;
    _priority = client.priority;
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _companyController.dispose();
    super.dispose();
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final data = {
        'firstName': _firstNameController.text.trim(),
        'lastName': _lastNameController.text.trim(),
        'phone': _phoneController.text.trim().isNotEmpty
            ? _phoneController.text.trim()
            : null,
        'email': _emailController.text.trim().isNotEmpty
            ? _emailController.text.trim()
            : null,
        'address': _addressController.text.trim().isNotEmpty
            ? _addressController.text.trim()
            : null,
        'company': _companyController.text.trim().isNotEmpty
            ? _companyController.text.trim()
            : null,
        'customerType': _customerType,
        'category': _category,
        'priority': _priority,
        'status': 'active',
        'creditLimit': 0.0,
        'paymentTerms': 30,
        'alertsEnabled': true,
        'creditLimitAlerts': true,
        'emailInvoices': false,
      };

      final result = _isEditing
          ? await _clientController.updateClient(widget.client!.id, data)
          : await _clientController.createClient(data);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message']),
            backgroundColor: result['success'] ? Colors.green : Colors.red,
          ),
        );

        if (result['success']) {
          widget.onSaved();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildModalHeader(),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildPersonalInfoSection(),
                  const SizedBox(height: 24),
                  _buildContactSection(),
                  const SizedBox(height: 24),
                  _buildBusinessSection(),
                ],
              ),
            ),
          ),
        ),
        _buildModalFooter(),
      ],
    );
  }

  Widget _buildModalHeader() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF7717E8), Color(0xFF9C27B0)],
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              _isEditing ? Icons.edit : Icons.person_add,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isEditing ? 'Modifier Client' : 'Nouveau Client',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  _isEditing
                      ? 'Modifiez les informations du client'
                      : 'Ajoutez un nouveau client à votre base',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: widget.onCancel,
            icon: const Icon(Icons.close, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalInfoSection() {
    return _buildSection('Informations personnelles', Icons.person, [
      Row(
        children: [
          Expanded(
            child: _buildModernTextField(
              controller: _firstNameController,
              label: 'Prénom',
              icon: Icons.person_outline,
              isRequired: true,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernTextField(
              controller: _lastNameController,
              label: 'Nom',
              icon: Icons.person_outline,
              isRequired: true,
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernTextField(
        controller: _companyController,
        label: 'Entreprise (optionnel)',
        icon: Icons.business,
      ),
    ]);
  }

  Widget _buildContactSection() {
    return _buildSection('Contact', Icons.contact_phone, [
      Row(
        children: [
          Expanded(
            child: _buildModernTextField(
              controller: _phoneController,
              label: 'Téléphone',
              icon: Icons.phone,
              keyboardType: TextInputType.phone,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernTextField(
              controller: _emailController,
              label: 'Email',
              icon: Icons.email,
              keyboardType: TextInputType.emailAddress,
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernTextField(
        controller: _addressController,
        label: 'Adresse',
        icon: Icons.location_on,
        maxLines: 2,
      ),
    ]);
  }

  Widget _buildBusinessSection() {
    return _buildSection('Informations commerciales', Icons.business_center, [
      Row(
        children: [
          Expanded(
            child: _buildModernDropdown(
              value: _customerType,
              label: 'Type de client',
              icon: Icons.category,
              items: const [
                {'value': 'particulier', 'label': 'Particulier'},
                {'value': 'entreprise', 'label': 'Entreprise'},
                {'value': 'administration', 'label': 'Administration'},
              ],
              onChanged: (value) => setState(() => _customerType = value!),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernDropdown(
              value: _category,
              label: 'Catégorie',
              icon: Icons.label,
              items: const [
                {'value': 'particulier', 'label': 'Particulier'},
                {'value': 'grossiste', 'label': 'Grossiste'},
                {'value': 'detaillant', 'label': 'Détaillant'},
                {'value': 'vip', 'label': 'VIP'},
              ],
              onChanged: (value) => setState(() => _category = value!),
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernDropdown(
        value: _priority,
        label: 'Priorité',
        icon: Icons.priority_high,
        items: const [
          {'value': 'bas', 'label': 'Faible'},
          {'value': 'normal', 'label': 'Normale'},
          {'value': 'haut', 'label': 'Élevée'},
        ],
        onChanged: (value) => setState(() => _priority = value!),
      ),
    ]);
  }

  Widget _buildSection(String title, IconData icon, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF7717E8).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: const Color(0xFF7717E8), size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D3748),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildModernTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isRequired = false,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: isRequired ? '$label *' : label,
        prefixIcon: Icon(icon, color: const Color(0xFF7717E8)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF7717E8), width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      validator: isRequired
          ? (value) =>
                value?.trim().isEmpty == true ? '$label est requis' : null
          : null,
    );
  }

  Widget _buildModernDropdown({
    required String value,
    required String label,
    required IconData icon,
    required List<Map<String, String>> items,
    required Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF7717E8)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF7717E8), width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      items: items.map((item) {
        return DropdownMenuItem<String>(
          value: item['value'],
          child: Text(item['label']!),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }

  Widget _buildModalFooter() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        border: Border(top: BorderSide(color: Colors.grey[200]!)),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _isLoading ? null : widget.onCancel,
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                side: BorderSide(color: Colors.grey[400]!),
              ),
              child: const Text(
                'Annuler',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              onPressed: _isLoading ? null : _submitForm,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7717E8),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Text(
                      _isEditing ? 'Modifier' : 'Créer',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Dialog pour ajouter une communication
class _CommunicationDialog extends StatefulWidget {
  @override
  State<_CommunicationDialog> createState() => _CommunicationDialogState();
}

class _CommunicationDialogState extends State<_CommunicationDialog> {
  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _contentController = TextEditingController();
  String _selectedType = 'call';

  @override
  void dispose() {
    _subjectController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Ajouter une communication'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: _selectedType,
              decoration: const InputDecoration(labelText: 'Type'),
              items: const [
                DropdownMenuItem(
                  value: 'call',
                  child: Text('Appel téléphonique'),
                ),
                DropdownMenuItem(value: 'email', child: Text('Email')),
                DropdownMenuItem(value: 'meeting', child: Text('Rendez-vous')),
                DropdownMenuItem(value: 'letter', child: Text('Courrier')),
              ],
              onChanged: (value) => setState(() => _selectedType = value!),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _subjectController,
              decoration: const InputDecoration(labelText: 'Sujet'),
              validator: (value) =>
                  value?.isEmpty == true ? 'Le sujet est requis' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _contentController,
              decoration: const InputDecoration(labelText: 'Contenu'),
              maxLines: 3,
              validator: (value) =>
                  value?.isEmpty == true ? 'Le contenu est requis' : null,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Annuler'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              Navigator.pop(context, {
                'type': _selectedType,
                'subject': _subjectController.text,
                'content': _contentController.text,
              });
            }
          },
          child: const Text('Ajouter'),
        ),
      ],
    );
  }
}

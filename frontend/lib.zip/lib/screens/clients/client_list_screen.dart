import 'package:flutter/material.dart';
import '../../controllers/client_controller.dart';
import '../../models/client.dart';
import 'client_detail_screen.dart';
// import 'client_form_screen.dart';

/// Écran de liste des clients avec filtres et recherche
/// Selon le plan Sprint 2 - Frontend Core
class ClientListScreen extends StatefulWidget {
  const ClientListScreen({Key? key}) : super(key: key);

  @override
  State<ClientListScreen> createState() => _ClientListScreenState();
}

class _ClientListScreenState extends State<ClientListScreen> {
  final ClientController _clientController = ClientController();
  final TextEditingController _searchController = TextEditingController();

  bool _isLoading = false;
  String _selectedStatus = 'all';
  String _selectedCategory = 'all';
  String _sortBy = 'createdAt';
  String _sortOrder = 'desc';

  @override
  void initState() {
    super.initState();
    _loadClients();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _clientController.updateSearchQuery(_searchController.text);
    setState(() {});
  }

  Future<void> _loadClients() async {
    setState(() => _isLoading = true);
    final success = await _clientController.loadClients();
    if (!success && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(_clientController.lastError)));
    }
    setState(() => _isLoading = false);
  }

  Future<void> _refreshClients() async {
    await _clientController.refresh();
    setState(() {});
  }

  void _onStatusFilterChanged(String? value) {
    if (value != null) {
      setState(() => _selectedStatus = value);
      _clientController.updateStatusFilter(value);
    }
  }

  void _onCategoryFilterChanged(String? value) {
    if (value != null) {
      setState(() => _selectedCategory = value);
      _clientController.updateCategoryFilter(value);
    }
  }

  void _onSortChanged(String field, String order) {
    setState(() {
      _sortBy = field;
      _sortOrder = order;
    });
    _clientController.updateSort(field, order);
  }

  void _clearFilters() {
    setState(() {
      _selectedStatus = 'all';
      _selectedCategory = 'all';
      _sortBy = 'createdAt';
      _sortOrder = 'desc';
    });
    _searchController.clear();
    _clientController.clearFilters();
  }

  void _navigateToClientDetail(Client client) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ClientDetailScreen(clientId: client.id),
      ),
    ).then((_) => _refreshClients());
  }

  void _navigateToCreateClient() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.6,
          height: MediaQuery.of(context).size.height * 0.8,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: _ClientFormModal(
            onSaved: () {
              Navigator.pop(context);
              _refreshClients();
            },
            onCancel: () => Navigator.pop(context),
          ),
        ),
      ),
    );
  }

  void _navigateToEditClient(Client client) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.6,
          height: MediaQuery.of(context).size.height * 0.8,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: _ClientFormModal(
            client: client,
            onSaved: () {
              Navigator.pop(context);
              _refreshClients();
            },
            onCancel: () => Navigator.pop(context),
          ),
        ),
      ),
    );
  }

  Future<void> _deleteClient(Client client) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmer la suppression'),
        content: Text(
          'Êtes-vous sûr de vouloir supprimer ${client.fullName} ?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final result = await _clientController.deleteClient(client.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message']),
            backgroundColor: result['success'] ? Colors.green : Colors.red,
          ),
        );
        if (result['success']) {
          setState(() {});
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildHeader(),
          _buildFilters(),
          _buildStats(),
          _buildClientsList(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white, Colors.grey[50]!],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey[200]!),
                  ),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Rechercher un client...',
                      hintStyle: TextStyle(color: Colors.grey[500]),
                      prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: Icon(Icons.clear, color: Colors.grey[400]),
                              onPressed: () {
                                _searchController.clear();
                                _onSearchChanged();
                              },
                            )
                          : null,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 14,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF7717E8), Color(0xFF9C27B0)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF7717E8).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: ElevatedButton.icon(
                  onPressed: _navigateToCreateClient,
                  icon: const Icon(Icons.add, color: Colors.white, size: 20),
                  label: const Text(
                    'Nouveau',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: IconButton(
                  onPressed: _refreshClients,
                  icon: Icon(Icons.refresh, color: Colors.grey[600]),
                  tooltip: 'Actualiser',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.08),
            spreadRadius: 1,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.filter_list, color: Colors.grey[600], size: 20),
              const SizedBox(width: 8),
              Text(
                'Filtres',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[700],
                ),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: _clearFilters,
                icon: const Icon(Icons.clear, size: 16),
                label: const Text('Effacer'),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.grey[600],
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildModernDropdown('Statut', _selectedStatus, [
                  {
                    'value': 'all',
                    'label': 'Tous',
                    'icon': Icons.all_inclusive,
                  },
                  {
                    'value': 'active',
                    'label': 'Actif',
                    'icon': Icons.check_circle,
                  },
                  {
                    'value': 'inactive',
                    'label': 'Inactif',
                    'icon': Icons.pause_circle,
                  },
                  {'value': 'blocked', 'label': 'Bloqué', 'icon': Icons.block},
                ], _onStatusFilterChanged),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildModernDropdown('Catégorie', _selectedCategory, [
                  {'value': 'all', 'label': 'Toutes', 'icon': Icons.category},
                  {
                    'value': 'particulier',
                    'label': 'Particulier',
                    'icon': Icons.person,
                  },
                  {
                    'value': 'grossiste',
                    'label': 'Grossiste',
                    'icon': Icons.business,
                  },
                  {
                    'value': 'detaillant',
                    'label': 'Détaillant',
                    'icon': Icons.store,
                  },
                ], _onCategoryFilterChanged),
              ),
              const SizedBox(width: 12),
              _buildSortDropdown(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildModernDropdown(
    String label,
    String value,
    List<Map<String, dynamic>> items,
    Function(String?) onChanged,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.grey[600], fontSize: 12),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 8,
          ),
        ),
        items: items.map((item) {
          return DropdownMenuItem<String>(
            value: item['value'],
            child: Row(
              children: [
                Icon(item['icon'], size: 16, color: Colors.grey[600]),
                const SizedBox(width: 8),
                Text(item['label']),
              ],
            ),
          );
        }).toList(),
        onChanged: onChanged,
        dropdownColor: Colors.white,
        style: TextStyle(color: Colors.grey[800], fontSize: 14),
      ),
    );
  }

  Widget _buildSortDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: DropdownButton<String>(
        value: '$_sortBy-$_sortOrder',
        underline: const SizedBox(),
        icon: Icon(Icons.sort, color: Colors.grey[600]),
        style: TextStyle(color: Colors.grey[800], fontSize: 14),
        items: const [
          DropdownMenuItem(value: 'createdAt-desc', child: Text('Plus récent')),
          DropdownMenuItem(value: 'createdAt-asc', child: Text('Plus ancien')),
          DropdownMenuItem(value: 'name-asc', child: Text('Nom A-Z')),
          DropdownMenuItem(value: 'name-desc', child: Text('Nom Z-A')),
          DropdownMenuItem(
            value: 'totalRevenue-desc',
            child: Text('CA décroissant'),
          ),
          DropdownMenuItem(
            value: 'creditScore-desc',
            child: Text('Meilleur score'),
          ),
        ],
        onChanged: (value) {
          if (value != null) {
            final parts = value.split('-');
            _onSortChanged(parts[0], parts[1]);
          }
        },
      ),
    );
  }

  Widget _buildStats() {
    final stats = _clientController.getQuickStats();

    return Container(
      margin: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Statistiques rapides',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildModernStatCard(
                  'Total Clients',
                  '${stats['totalClients']}',
                  Icons.people,
                  const Color(0xFF7717E8),
                  Colors.purple[50]!,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildModernStatCard(
                  'Clients Actifs',
                  '${stats['activeClients']}',
                  Icons.check_circle,
                  Colors.green,
                  Colors.green[50]!,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildModernStatCard(
                  'Chiffre d\'Affaires',
                  '${(stats['totalRevenue'] / 1000).toStringAsFixed(0)}K F',
                  Icons.trending_up,
                  Colors.blue,
                  Colors.blue[50]!,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildModernStatCard(
                  'Créances',
                  '${(stats['totalOutstanding'] / 1000).toStringAsFixed(0)}K F',
                  Icons.warning,
                  Colors.orange,
                  Colors.orange[50]!,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildModernStatCard(
                  'Score Moyen',
                  '${stats['averageScore'].toStringAsFixed(1)}/10',
                  Icons.star,
                  Colors.amber,
                  Colors.amber[50]!,
                ),
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: SizedBox(),
              ), // Espace vide pour l'équilibrage
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildModernStatCard(
    String label,
    String value,
    IconData icon,
    Color color,
    Color backgroundColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildClientsList() {
    if (_isLoading) {
      return Container(
        height: 200,
        child: const Center(child: CircularProgressIndicator()),
      );
    }

    final clients = _clientController.filteredClients;

    if (clients.isEmpty) {
      return Container(
        height: 200,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.people_outline, size: 64, color: Colors.grey[400]),
              const SizedBox(height: 16),
              Text(
                'Aucun client trouvé',
                style: TextStyle(fontSize: 18, color: Colors.grey[600]),
              ),
              const SizedBox(height: 8),
              Text(
                'Ajustez vos filtres ou créez un nouveau client',
                style: TextStyle(color: Colors.grey[500]),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: clients.map((client) => _buildClientCard(client)).toList(),
    );
  }

  Widget _buildClientCard(Client client) {
    final statusColor = _getStatusColor(client.status);
    final scoreColor = _getScoreColor(client.creditScore);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => _navigateToClientDetail(client),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // Avatar avec statut
              Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [statusColor.withOpacity(0.8), statusColor],
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      client.firstName.isNotEmpty
                          ? client.firstName[0].toUpperCase()
                          : '?',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  if (client.currentOutstanding > 0)
                    Positioned(
                      top: -2,
                      right: -2,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 16),

              // Informations principales
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            client.fullName,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Color(0xFF2D3748),
                            ),
                          ),
                        ),
                        _buildStatusChip(client.status, statusColor),
                      ],
                    ),
                    const SizedBox(height: 4),

                    // Contact et catégorie
                    Text(
                      '${client.phone ?? 'N/A'} • ${client.categoryDisplay}',
                      style: TextStyle(color: Colors.grey[600], fontSize: 14),
                    ),
                    if (client.company != null &&
                        client.company!.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        client.company!,
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 12,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],

                    const SizedBox(height: 8),

                    // Métriques
                    Row(
                      children: [
                        _buildMetricChip(
                          'CA',
                          '${(client.totalRevenue / 1000).toStringAsFixed(0)}K F',
                          Colors.blue,
                          Icons.trending_up,
                        ),
                        const SizedBox(width: 8),
                        _buildMetricChip(
                          'Score',
                          '${client.creditScore.toStringAsFixed(1)}/10',
                          scoreColor,
                          Icons.star,
                        ),
                        if (client.currentOutstanding > 0) ...[
                          const SizedBox(width: 8),
                          _buildMetricChip(
                            'Créances',
                            '${(client.currentOutstanding / 1000).toStringAsFixed(0)}K F',
                            Colors.red,
                            Icons.warning,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),

              // Menu d'actions
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: PopupMenuButton<String>(
                  onSelected: (value) {
                    switch (value) {
                      case 'view':
                        _navigateToClientDetail(client);
                        break;
                      case 'edit':
                        _navigateToEditClient(client);
                        break;
                      case 'delete':
                        _deleteClient(client);
                        break;
                    }
                  },
                  icon: Icon(Icons.more_vert, color: Colors.grey[600]),
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'view',
                      child: Row(
                        children: [
                          Icon(Icons.visibility, size: 18),
                          SizedBox(width: 8),
                          Text('Voir détails'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit, size: 18),
                          SizedBox(width: 8),
                          Text('Modifier'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete, size: 18, color: Colors.red),
                          SizedBox(width: 8),
                          Text(
                            'Supprimer',
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusChip(String status, Color color) {
    String label;
    switch (status) {
      case 'active':
        label = 'Actif';
        break;
      case 'blocked':
        label = 'Bloqué';
        break;
      default:
        label = 'Inactif';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildMetricChip(
    String label,
    String value,
    Color color,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            '$label: $value',
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'active':
        return Colors.green;
      case 'blocked':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Color _getScoreColor(double score) {
    if (score >= 8) return Colors.green;
    if (score >= 6) return Colors.blue;
    if (score >= 4) return Colors.orange;
    return Colors.red;
  }
}

/// Widget modal pour créer un nouveau client avec design moderne
class _ClientFormModal extends StatefulWidget {
  final VoidCallback onSaved;
  final VoidCallback onCancel;
  final Client? client;

  const _ClientFormModal({
    required this.onSaved,
    required this.onCancel,
    this.client,
  });

  @override
  State<_ClientFormModal> createState() => _ClientFormModalState();
}

class _ClientFormModalState extends State<_ClientFormModal> {
  final _formKey = GlobalKey<FormState>();
  final ClientController _clientController = ClientController();

  // Controllers
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _companyController = TextEditingController();

  // Form values
  String _customerType = 'particulier';
  String _category = 'particulier';
  String _priority = 'bas';
  bool _isLoading = false;

  bool get _isEditing => widget.client != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      _initializeForm();
    }
  }

  void _initializeForm() {
    final client = widget.client!;
    _firstNameController.text = client.firstName;
    _lastNameController.text = client.lastName;
    _phoneController.text = client.phone ?? '';
    _emailController.text = client.email ?? '';
    _addressController.text = client.address ?? '';
    _companyController.text = client.company ?? '';
    _customerType = client.customerType;
    _category = client.category;
    _priority = client.priority;
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _companyController.dispose();
    super.dispose();
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final data = {
        'firstName': _firstNameController.text.trim(),
        'lastName': _lastNameController.text.trim(),
        'phone': _phoneController.text.trim().isNotEmpty
            ? _phoneController.text.trim()
            : null,
        'email': _emailController.text.trim().isNotEmpty
            ? _emailController.text.trim()
            : null,
        'address': _addressController.text.trim().isNotEmpty
            ? _addressController.text.trim()
            : null,
        'company': _companyController.text.trim().isNotEmpty
            ? _companyController.text.trim()
            : null,
        'customerType': _customerType,
        'category': _category,
        'priority': _priority,
        'status': 'active',
        'creditLimit': 0.0,
        'paymentTerms': 30,
        'alertsEnabled': true,
        'creditLimitAlerts': true,
        'emailInvoices': false,
      };

      final result = _isEditing
          ? await _clientController.updateClient(widget.client!.id, data)
          : await _clientController.createClient(data);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message']),
            backgroundColor: result['success'] ? Colors.green : Colors.red,
          ),
        );

        if (result['success']) {
          widget.onSaved();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildModalHeader(),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildPersonalInfoSection(),
                  const SizedBox(height: 24),
                  _buildContactSection(),
                  const SizedBox(height: 24),
                  _buildBusinessSection(),
                ],
              ),
            ),
          ),
        ),
        _buildModalFooter(),
      ],
    );
  }

  Widget _buildModalHeader() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF7717E8), Color(0xFF9C27B0)],
        ),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              _isEditing ? Icons.edit : Icons.person_add,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isEditing ? 'Modifier Client' : 'Nouveau Client',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  _isEditing
                      ? 'Modifiez les informations du client'
                      : 'Ajoutez un nouveau client à votre base',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: widget.onCancel,
            icon: const Icon(Icons.close, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalInfoSection() {
    return _buildSection('Informations personnelles', Icons.person, [
      Row(
        children: [
          Expanded(
            child: _buildModernTextField(
              controller: _firstNameController,
              label: 'Prénom',
              icon: Icons.person_outline,
              isRequired: true,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernTextField(
              controller: _lastNameController,
              label: 'Nom',
              icon: Icons.person_outline,
              isRequired: true,
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernTextField(
        controller: _companyController,
        label: 'Entreprise (optionnel)',
        icon: Icons.business,
      ),
    ]);
  }

  Widget _buildContactSection() {
    return _buildSection('Contact', Icons.contact_phone, [
      Row(
        children: [
          Expanded(
            child: _buildModernTextField(
              controller: _phoneController,
              label: 'Téléphone',
              icon: Icons.phone,
              keyboardType: TextInputType.phone,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernTextField(
              controller: _emailController,
              label: 'Email',
              icon: Icons.email,
              keyboardType: TextInputType.emailAddress,
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernTextField(
        controller: _addressController,
        label: 'Adresse',
        icon: Icons.location_on,
        maxLines: 2,
      ),
    ]);
  }

  Widget _buildBusinessSection() {
    return _buildSection('Informations commerciales', Icons.business_center, [
      Row(
        children: [
          Expanded(
            child: _buildModernDropdown(
              value: _customerType,
              label: 'Type de client',
              icon: Icons.category,
              items: const [
                {'value': 'particulier', 'label': 'Particulier'},
                {'value': 'entreprise', 'label': 'Entreprise'},
                {'value': 'administration', 'label': 'Administration'},
              ],
              onChanged: (value) => setState(() => _customerType = value!),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildModernDropdown(
              value: _category,
              label: 'Catégorie',
              icon: Icons.label,
              items: const [
                {'value': 'particulier', 'label': 'Particulier'},
                {'value': 'grossiste', 'label': 'Grossiste'},
                {'value': 'detaillant', 'label': 'Détaillant'},
                {'value': 'vip', 'label': 'VIP'},
              ],
              onChanged: (value) => setState(() => _category = value!),
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildModernDropdown(
        value: _priority,
        label: 'Priorité',
        icon: Icons.priority_high,
        items: const [
          {'value': 'bas', 'label': 'Faible'},
          {'value': 'normal', 'label': 'Normale'},
          {'value': 'haut', 'label': 'Élevée'},
        ],
        onChanged: (value) => setState(() => _priority = value!),
      ),
    ]);
  }

  Widget _buildSection(String title, IconData icon, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF7717E8).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: const Color(0xFF7717E8), size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D3748),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildModernTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isRequired = false,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: isRequired ? '$label *' : label,
        prefixIcon: Icon(icon, color: const Color(0xFF7717E8)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF7717E8), width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      validator: isRequired
          ? (value) =>
                value?.trim().isEmpty == true ? '$label est requis' : null
          : null,
    );
  }

  Widget _buildModernDropdown({
    required String value,
    required String label,
    required IconData icon,
    required List<Map<String, String>> items,
    required Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color(0xFF7717E8)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF7717E8), width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      items: items.map((item) {
        return DropdownMenuItem<String>(
          value: item['value'],
          child: Text(item['label']!),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }

  Widget _buildModalFooter() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        border: Border(top: BorderSide(color: Colors.grey[200]!)),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _isLoading ? null : widget.onCancel,
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                side: BorderSide(color: Colors.grey[400]!),
              ),
              child: const Text(
                'Annuler',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              onPressed: _isLoading ? null : _submitForm,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7717E8),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Text(
                      _isEditing ? 'Modifier' : 'Créer',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

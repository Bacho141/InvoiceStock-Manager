import 'package:flutter/material.dart';
import '../../models/client.dart';

/// Écran de test minimal pour ClientFormScreen
class ClientFormTestScreen extends StatefulWidget {
  final Client? client;

  const ClientFormTestScreen({Key? key, this.client}) : super(key: key);

  @override
  State<ClientFormTestScreen> createState() => _ClientFormTestScreenState();
}

class _ClientFormTestScreenState extends State<ClientFormTestScreen> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    print('Initialisation de ClientFormTestScreen');
    if (widget.client != null) {
      print(
        'Client reçu: ${widget.client!.firstName} ${widget.client!.lastName}',
      );
      _firstNameController.text = widget.client!.firstName;
      _lastNameController.text = widget.client!.lastName;
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('Construction de ClientFormTestScreen');
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.client != null ? 'Modifier Client' : 'Nouveau Client',
        ),
        backgroundColor: const Color(0xFF7717E8),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _firstNameController,
              decoration: const InputDecoration(labelText: 'Prénom'),
            ),
            TextField(
              controller: _lastNameController,
              decoration: const InputDecoration(labelText: 'Nom'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Retour'),
            ),
          ],
        ),
      ),
    );
  }
}
